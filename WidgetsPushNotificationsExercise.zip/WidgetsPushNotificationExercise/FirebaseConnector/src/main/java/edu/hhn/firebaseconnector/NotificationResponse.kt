package edu.hhn.firebaseconnector

data class NotificationResponse(
    val success: Boolean,
    val message: String
)
