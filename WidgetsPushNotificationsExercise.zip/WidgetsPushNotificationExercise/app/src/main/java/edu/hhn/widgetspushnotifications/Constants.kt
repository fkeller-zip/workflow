package edu.hhn.widgetspushnotifications

object Constants {
    const val BROADCAST_TOPIC = "broadcast"
}
